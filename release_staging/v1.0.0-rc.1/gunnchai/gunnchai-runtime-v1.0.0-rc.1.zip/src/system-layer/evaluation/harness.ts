/**
 * Continuance VII evaluation harness.
 * Per capability records: baseline, dataset, quality metric, latency, memory,
 * failure, privacy, fallback, model version, mechanism, real-inference metrics.
 * Emits GUNNCHAI_REAL_LOCAL_INFERENCE_PASS when real local inference + evals pass.
 * FULL_GUNNCHAI3K_PLATFORM_DIGITAL_COMPLETE / DIGITALLY_VALIDATED are earned by
 * platform_status (Discord not normative) — harness alone does not claim them.
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import {
  CAPABILITY_SPECS,
  assertNotTextOnly,
  runNonAiBaseline,
  scoreSystemAgainstBaseline,
  type CapabilityEvalSpec,
  type MetricScore,
} from './metrics';
import { LocalInferenceRuntimeAdapter } from '../local_inference/runtime_adapter';
import { LlamaCppBackend } from '../local_inference/backends/llamacpp';
import { routeTask } from '../task_router';
import { mechanismFor } from '../capability_mechanisms';
import type { DeviceProfileId, SystemCapability } from '../model_registry';
import { evaluateCloudDisclosure } from '../privacy_policy';

export const FOUNDATION_EVAL_TOKEN = 'GUNNCHAI3K_SYSTEM_LAYER_FOUNDATION_EVAL_PASS';
export const CAPABILITY_EVAL_TOKEN = 'GUNNCHAI3K_LOCAL_RUNTIME_CAPABILITY_EVAL_PASS';
export const REAL_LOCAL_INFERENCE_TOKEN = 'GUNNCHAI_REAL_LOCAL_INFERENCE_PASS';
export const DIGITALLY_VALIDATED_TOKEN = 'DIGITALLY_VALIDATED';
export const FULL_PLATFORM_TOKEN = 'FULL_GUNNCHAI3K_PLATFORM_DIGITAL_COMPLETE';

/** Measured real-inference memory budget (peak RSS). */
const MEASURED_MEMORY_BUDGET_BYTES = 512 * 1024 * 1024;
/** Cold-start tolerant latency for small GGUF on constrained hosts. */
const MEASURED_LATENCY_BUDGET_MS = 60_000;

export interface CapabilityEvalResult {
  spec: CapabilityEvalSpec;
  metric: MetricScore;
  latencyMs: number;
  memoryStubBytes: number;
  withinLatencyBudget: boolean;
  withinMemoryBudget: boolean;
  fallback: string;
  privacy: {
    class: CapabilityEvalSpec['privacyClass'];
    cloudPermitted: boolean;
    disclosure: string;
  };
  failureObserved: string | null;
  modelVersion: string;
  metricsMode: 'measured' | 'placeholder_no_model';
  realInference: boolean;
  mechanism: string;
  passed: boolean;
  sampleTextPreview: string;
  llamaMetrics?: unknown;
}

export interface HarnessReport {
  token: string | null;
  foundationToken: string | null;
  realLocalInferenceToken: string | null;
  /** Harness never self-claims FULL/DIGITALLY — platform_status decides Cont VII. */
  digitallyValidatedClaimed: false;
  fullPlatformCompleteClaimed: false;
  digitallyValidatedReason: string;
  fullPlatformReason: string;
  selectedArchitecture: 'llama.cpp';
  llamaProbe: ReturnType<LlamaCppBackend['probe']>;
  results: CapabilityEvalResult[];
  passedCount: number;
  totalCount: number;
  allPassed: boolean;
  realInferenceCount: number;
}

const PROBES: Record<SystemCapability, { query: string; device: DeviceProfileId }> = {
  tutoring: { query: 'teach binary search', device: 'student_14_5' },
  code: { query: 'typescript early return guard', device: 'ds_xl_coder' },
  device_help: { query: 'device storage health check', device: 'handheld_hybrid' },
  a11y: { query: 'icon button without label', device: 'student_14_5' },
  game_coach: { query: 'fast tempo mid fight reset', device: 'student_14_5' },
  network: { query: 'offline bearer diagnosis', device: 'student_14_5' },
  rag: { query: 'binary search tutoring fixture', device: 'student_14_5' },
  scientific: { query: 'binary search complexity claim', device: 'student_14_5' },
  translation: { query: 'en to es: hello', device: 'student_14_5' },
  workflow: { query: 'automate local study flashcard export', device: 'student_14_5' },
  security: { query: 'explain phishing defense locally', device: 'student_14_5' },
};

const FOUNDATION_CAPS: SystemCapability[] = [
  'tutoring',
  'code',
  'device_help',
  'game_coach',
  'network',
  'rag',
];

export async function runEvaluationHarness(
  adapter = new LocalInferenceRuntimeAdapter(),
  cwd = process.cwd(),
): Promise<HarnessReport> {
  const results: CapabilityEvalResult[] = [];
  const llama = new LlamaCppBackend(cwd);
  const llamaProbe = llama.probe();

  for (const spec of CAPABILITY_SPECS) {
    const probe = PROBES[spec.capability];
    const mech = mechanismFor(spec.capability);
    const route = routeTask({
      capability: spec.capability,
      query: probe.query,
      processingMode: 'local-only',
      deviceProfileId: probe.device,
    });

    const disclosure = evaluateCloudDisclosure({
      processingMode: 'local-only',
      userCloudConsent: false,
      containsSensitiveLocalData: false,
      capability: spec.capability,
    });

    const inference = await adapter.infer({
      capability: spec.capability,
      query: probe.query,
      deviceProfileId: probe.device,
      preferredBackend: route.preferredBackend,
    });

    assertNotTextOnly(inference);

    const baseline = runNonAiBaseline(spec.capability, probe.query);
    const metric = scoreSystemAgainstBaseline(
      spec.capability,
      inference,
      baseline,
    );

    const metricsMode =
      inference.structured.metricsMode === 'measured'
        ? 'measured'
        : 'placeholder_no_model';
    const realInference = inference.structured.realInference === true;

    const latencyBudget = realInference
      ? Math.max(spec.latencyBudgetMs, MEASURED_LATENCY_BUDGET_MS)
      : spec.latencyBudgetMs;
    const memoryBudget = realInference
      ? Math.max(spec.memoryStubBudgetBytes, MEASURED_MEMORY_BUDGET_BYTES)
      : spec.memoryStubBudgetBytes;

    const withinLatencyBudget = inference.latencyMs <= latencyBudget;
    const withinMemoryBudget = inference.memoryStubBytes <= memoryBudget;

    const failureObserved =
      inference.fallbackUsed && inference.structured.failure
        ? String(inference.structured.failure)
        : metric.metricName === 'insufficient_text_only'
          ? 'text_only'
          : null;

    const passed =
      metric.structuredEvaluation &&
      metric.beatsOrComplementsBaseline &&
      withinLatencyBudget &&
      withinMemoryBudget &&
      metric.metricName !== 'insufficient_text_only';

    results.push({
      spec,
      metric,
      latencyMs: inference.latencyMs,
      memoryStubBytes: inference.memoryStubBytes,
      withinLatencyBudget,
      withinMemoryBudget,
      fallback: inference.fallbackReason ?? spec.fallbackDescription,
      privacy: {
        class: spec.privacyClass,
        cloudPermitted: disclosure.cloudPermitted,
        disclosure: disclosure.userVisibleDisclosure,
      },
      failureObserved,
      modelVersion: spec.modelVersion,
      metricsMode,
      realInference,
      mechanism: mech.mechanism,
      passed,
      sampleTextPreview: inference.text.slice(0, 180),
      llamaMetrics: inference.structured.llamaMetrics,
    });
  }

  const passedCount = results.filter((r) => r.passed).length;
  const allPassed = passedCount === results.length;
  const foundationPassed = results
    .filter((r) => FOUNDATION_CAPS.includes(r.spec.capability))
    .every((r) => r.passed);
  const realInferenceCount = results.filter((r) => r.realInference).length;
  const realPassEligible =
    llamaProbe.canRunRealInference &&
    realInferenceCount >= 1 &&
    allPassed &&
    results.some(
      (r) =>
        r.realInference &&
        r.llamaMetrics &&
        typeof r.llamaMetrics === 'object',
    );

  const report: HarnessReport = {
    token: allPassed ? CAPABILITY_EVAL_TOKEN : null,
    foundationToken: foundationPassed ? FOUNDATION_EVAL_TOKEN : null,
    realLocalInferenceToken: realPassEligible
      ? REAL_LOCAL_INFERENCE_TOKEN
      : null,
    digitallyValidatedClaimed: false,
    fullPlatformCompleteClaimed: false,
    digitallyValidatedReason:
      `${DIGITALLY_VALIDATED_TOKEN} is decided by platform_status (Cont VII). ` +
      `Harness emits ${CAPABILITY_EVAL_TOKEN} / ${FOUNDATION_EVAL_TOKEN} / ${REAL_LOCAL_INFERENCE_TOKEN} only. Discord is not normative.`,
    fullPlatformReason:
      `${FULL_PLATFORM_TOKEN} is decided by platform_status (Cont VII). ` +
      `llama.cpp real inference=${llamaProbe.canRunRealInference}; ` +
      `realInferenceCount=${realInferenceCount}; ` +
      `Discord/cloud are optional surfaces — not automatic blockers.`,
    selectedArchitecture: 'llama.cpp',
    llamaProbe,
    results,
    passedCount,
    totalCount: results.length,
    allPassed,
    realInferenceCount,
  };

  const evidenceDir = path.join(cwd, 'evidence', 'system-layer');
  fs.mkdirSync(evidenceDir, { recursive: true });
  const serializable = {
    generatedAt: new Date().toISOString(),
    continuation: 'VII',
    ...report,
    results: report.results.map((r) => ({
      capability: r.spec.capability,
      purpose: r.spec.purpose,
      mechanism: r.mechanism,
      nonAiBaseline: r.spec.nonAiBaselineName,
      datasetId: r.spec.datasetId,
      datasetSize: r.spec.datasetSize,
      metric: r.metric.metricName,
      systemScore: r.metric.systemScore,
      baselineScore: r.metric.baselineScore,
      beatsOrComplementsBaseline: r.metric.beatsOrComplementsBaseline,
      latencyMs: r.latencyMs,
      memoryStubBytes: r.memoryStubBytes,
      failureObserved: r.failureObserved,
      privacyClass: r.privacy.class,
      cloudPermitted: r.privacy.cloudPermitted,
      fallback: r.fallback.slice(0, 240),
      modelVersion: r.modelVersion,
      metricsMode: r.metricsMode,
      realInference: r.realInference,
      llamaMetrics: r.llamaMetrics ?? null,
      passed: r.passed,
    })),
  };
  const writeEvidence = (name: string, payload: unknown) => {
    try {
      fs.writeFileSync(path.join(evidenceDir, name), JSON.stringify(payload, null, 2));
    } catch {
      // Evidence writes are best-effort in sandboxed CI/dev environments.
    }
  };
  writeEvidence('CONTINUATION_VII_STATUS.json', serializable);
  writeEvidence('CONTINUATION_VI_STATUS.json', serializable);
  // Keep V/IV/III filenames updated for back-compat readers
  writeEvidence('CONTINUATION_V_STATUS.json', serializable);
  writeEvidence('CONTINUATION_IV_STATUS.json', serializable);
  writeEvidence('CONTINUATION_III_STATUS.json', serializable);

  return report;
}
