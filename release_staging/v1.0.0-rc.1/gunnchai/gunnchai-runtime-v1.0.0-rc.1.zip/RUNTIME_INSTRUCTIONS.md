# gunnchAI RC1 runtime instructions

1. Use accepted-main pin ef665648…
2. Do not ship unauthorized model weights.
3. If Nearby Mac is unavailable, show truthful fallback/unavailable — never fake product inference.
4. WAIKE consumer integration child e2d1adc… must remain on main.
