(export
	(version "E")
	(design
		(source "/Users/gunnchos/Downloads/gunnchos-7gc-research-product-spine/repos/gunnchos-hardware-industrial-design/device_designs/student_14_5/kicad/student_14_5.kicad_sch")
		(date "2026-08-08T16:01:45")
		(tool "Eeschema 10.0.5")
		(textvar
			(name "EDMUND_ACTION_REQUIRED") "install_kicad_cli")
		(textvar
			(name "FAMILY_DEPTH") "1")
		(textvar
			(name "KICAD_CLI") "ABSENT")
		(sheet
			(number "1")
			(name "/")
			(tstamps "/")
			(title_block
				(title "Student 14.5 Carrier — student_14_5_carrier")
				(company "gunnchOS3k / HARDWARE DESIGN RELEASE")
				(rev "0.3.0-dev")
				(date "2026-08-08")
				(source "student_14_5.kicad_sch")
				(comment
					(number "1")
					(value "COM module + carrier — NO bare CPU BGA")
				)
				(comment
					(number "2")
					(value "ADR-HW-001 / ADR-FP-001")
				)
				(comment
					(number "3")
					(value "kicad-cli ABSENT → EDMUND_ACTION_REQUIRED")
				)
				(comment
					(number "4")
					(value "PHYSICAL_EXECUTION_FREEZE ACTIVE — no fab, no purchase, draft digital only")
				)
				(comment
					(number "5")
					(value "")
				)
				(comment
					(number "6")
					(value "")
				)
				(comment
					(number "7")
					(value "")
				)
				(comment
					(number "8")
					(value "")
				)
				(comment
					(number "9")
					(value "")
				)
			)
		)
	)
	(components)
	(groups)
	(variants)
	(libparts)
	(libraries)
	(nets)
)
