%TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*%
%TF.CreationDate,2026-08-08T16:04:30-05:00*%
%TF.ProjectId,dock,646f636b-2e6b-4696-9361-645f70636258,0.3.0-cont-vi*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-08 16:04:30*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
