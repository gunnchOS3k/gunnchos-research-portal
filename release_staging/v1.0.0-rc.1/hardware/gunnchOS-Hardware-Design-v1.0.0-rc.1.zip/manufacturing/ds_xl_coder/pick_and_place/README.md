CPL: after layout complete
