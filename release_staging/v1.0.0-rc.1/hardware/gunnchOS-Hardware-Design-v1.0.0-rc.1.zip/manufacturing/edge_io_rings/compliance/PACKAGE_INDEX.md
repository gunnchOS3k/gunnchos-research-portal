# edge_io_rings — compliance prep (Cont VII)

See `docs/full_product_family/CERT_DIGITAL_PREP.md`.
No USB-IF / FCC / CE claims. Technical-file index only.
