# AI policy — DATA_VIZ_BI

Source: `curriculum/digital_rc/DATA_VIZ_BI/ai_use_policy.json`

## Allowed assistant modes

EXPLAIN, HINT, QUESTION_ME, DEBUG_WITH_ME, REVIEW_MY_WORK, COMPARE_APPROACHES, PRACTICE

## Assessment modes

AI_ALLOWED, AI_RESTRICTED, AI_DISCLOSED, NO_AI

## Package notes

Viz bench: AI may suggest chart types; graded dashboard fidelity checks against fixture tables are AI_RESTRICTED; no misleading insight without data path.


## Reviewer checks

- Graded security / research-claim practicals should default toward **NO_AI** or **AI_RESTRICTED** where the package says so.
- Learner submissions using assistants need **AI_DISCLOSED** when required.
- Do not allow “print PASS” or empty JSON as AI-assisted lab completion.
