# AI policy — GUNNCHOS_PRODUCT_LAB

Source: `curriculum/digital_rc/GUNNCHOS_PRODUCT_LAB/ai_use_policy.json`

## Allowed assistant modes

EXPLAIN, HINT, QUESTION_ME, DEBUG_WITH_ME, REVIEW_MY_WORK, COMPARE_APPROACHES, PRACTICE

## Assessment modes

AI_ALLOWED, AI_RESTRICTED, AI_DISCLOSED, NO_AI

## Package notes

gunnchOS Product Lab: charter/compat/checkout labs reject fabricated EVT claims; AI may critique PR text under AI_DISCLOSED; keys stay instructor-only.


## Reviewer checks

- Graded security / research-claim practicals should default toward **NO_AI** or **AI_RESTRICTED** where the package says so.
- Learner submissions using assistants need **AI_DISCLOSED** when required.
- Do not allow “print PASS” or empty JSON as AI-assisted lab completion.
