# AI policy — SOFTWARE_BUILDER

Source: `curriculum/digital_rc/SOFTWARE_BUILDER/ai_use_policy.json`

## Allowed assistant modes

EXPLAIN, HINT, QUESTION_ME, DEBUG_WITH_ME, REVIEW_MY_WORK, COMPARE_APPROACHES, PRACTICE

## Assessment modes

AI_ALLOWED, AI_RESTRICTED, AI_DISCLOSED, NO_AI

## Package notes

Weekly defaults AI_DISCLOSED for critiques; security practical NO_AI; migration SQL AI_RESTRICTED.

## Reviewer checks

- Graded security / research-claim practicals should default toward **NO_AI** or **AI_RESTRICTED** where the package says so.
- Learner submissions using assistants need **AI_DISCLOSED** when required.
- Do not allow “print PASS” or empty JSON as AI-assisted lab completion.
