# AI policy — DATA_DASHBOARDS

Source: `curriculum/digital_rc/DATA_DASHBOARDS/ai_use_policy.json`

## Allowed assistant modes

EXPLAIN, HINT, QUESTION_ME, DEBUG_WITH_ME, REVIEW_MY_WORK, COMPARE_APPROACHES, PRACTICE

## Assessment modes

AI_ALLOWED, AI_RESTRICTED, AI_DISCLOSED, NO_AI

## Package notes

Pier Ledger Bench: AI may draft SQL critiques under AI_DISCLOSED; schema-change practicals default AI_RESTRICTED; dashboard KPI claims must cite fixture rows, not invented impact.


## Reviewer checks

- Graded security / research-claim practicals should default toward **NO_AI** or **AI_RESTRICTED** where the package says so.
- Learner submissions using assistants need **AI_DISCLOSED** when required.
- Do not allow “print PASS” or empty JSON as AI-assisted lab completion.
