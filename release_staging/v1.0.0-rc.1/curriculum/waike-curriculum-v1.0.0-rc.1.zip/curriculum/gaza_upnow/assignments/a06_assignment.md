# Assignment 6 — Cybersecurity and privacy tabletop

> **Conceptual only — not for construction**
> Expert review required before construction or field deployment.
> Requires licensed architect/engineer review before construction.
> Do not publish sensitive locations, learner identities, family movements, shelter locations, or private recovery data.


**Course:** WAIKE Gaza UPNOW: Learn, Repair, Rebuild
**Week 6:** Cybersecurity, privacy, data protection, and threat modeling

## Deliverables

1. Written memo (500–800 words) with evidence labels
2. Diagram or table as specified
3. Community benefit tie-in paragraph

## Rubric mapping

| Criterion | Points |
|-----------|--------|
| Local accountability | 25 |
| Documentation | 25 |
| Safety/ethics | 25 |
| Technical quality | 25 |

## Portfolio artifact

Upload to portfolio folder: `a06_gaza_assignment.md`

## Provenance note

**Proven:** curriculum structure | **Assumed:** local partner names | **Needs validation:** field measurements
