# Lab 4 — Device repair, sensor, and hardware safety lab

> **Conceptual only — not for construction**
> Expert review required before construction or field deployment.
> Requires licensed architect/engineer review before construction.
> Do not publish sensitive locations, learner identities, family movements, shelter locations, or private recovery data.


**Duration:** 90 minutes (adjust for connectivity)

## Setup

- Devices as available; offline pack if needed
- Partner-approved space only

## Steps

1. Document starting assumptions (evidence labels)
2. Execute lab procedure for week 4
3. Record results in lab journal
4. Note RF/acoustic observations if relevant

## Student deliverable

`lab_04_report.md` with screenshots or tables (no sensitive locations for Gaza)

## Instructor checklist

- [ ] Safety briefing complete
- [ ] Privacy check for public sharing
- [ ] Trauma-aware pacing (Gaza)
