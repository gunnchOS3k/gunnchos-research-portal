# Week 10 Lecture — Community project sprint

> **Conceptual only — not for construction**
> Expert review required before construction or field deployment.
> Requires licensed architect/engineer review before construction.


**Site module emphasis:** phone-to-laptop transition

## Learning objectives

1. Explain how this week supports **WAIKE Ghana UPNOW** public benefit.
2. Complete documentation with evidence labels.
3. Identify what is proven vs assumed vs needs validation.

## Instructor notes

- Pace for local connectivity realities.
- Use sound-isolated room examples, not "fully soundproof."
- Portfolio artifact: week 10 reflection memo.

## Quiz questions

1. What is the local accountability goal this week? (open-book)
2. Name one RF/acoustic tradeoff relevant to ghana. (partial credit)
3. Label one claim as brief-derived vs design assumption.

## Provenance

| Item | Status |
|------|--------|
| Learning objectives | brief-derived |
| Technical examples | design assumption |
| Field measurements | expert review required |
