# Assignment 10 — Conceptual floor plan

> **Conceptual only — not for construction**
> Expert review required before construction or field deployment.
> Requires licensed architect/engineer review before construction.


**Course:** WAIKE Ghana UPNOW: Build, Ship, Serve
**Week 10:** Community project sprint

## Deliverables

1. Written memo (500–800 words) with evidence labels
2. Diagram or table as specified
3. Community benefit tie-in paragraph

## Rubric mapping

| Criterion | Points |
|-----------|--------|
| Local accountability | 25 |
| Documentation | 25 |
| Safety/ethics | 25 |
| Technical quality | 25 |

## Portfolio artifact

Upload to portfolio folder: `a10_ghana_assignment.md`

## Provenance note

**Proven:** curriculum structure | **Assumed:** local partner names | **Needs validation:** field measurements
