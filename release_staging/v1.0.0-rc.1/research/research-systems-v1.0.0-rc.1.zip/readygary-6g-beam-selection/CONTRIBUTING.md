# Contributing

1. Branch from `main` (or the active release pin).
2. Keep PRs focused; do not land unrelated features into an RC freeze.
3. No secrets, PII, or private competition / field data.
4. Public product feedback → portal [FEEDBACK.md](https://github.com/gunnchOS3k/gunnchos-research-portal/blob/release/v1.0.0-rc1-ecosystem-freeze/FEEDBACK.md).
5. Security vulnerabilities → private advisories only ([SECURITY.md](SECURITY.md)).

## Feedback & Suggestions

Public feedback: https://github.com/gunnchOS3k/gunnchos-research-portal/blob/main/FEEDBACK.md  
Security (private): https://github.com/gunnchOS3k/gunnchos-research-portal/blob/main/SECURITY.md  
Do not post exploitable security details publicly.
