# Reproduce readygary-6g-beam-selection (RC1)

Accepted main: `569875224db7812890ec6abc48dfe43a608094f3`

```bash
git clone https://github.com/gunnchOS3k/readygary-6g-beam-selection.git
cd readygary-6g-beam-selection
git checkout 569875224db7812890ec6abc48dfe43a608094f3
# follow README / Makefile demos on that commit
```

Evidence boundary: see RESEARCH_V1.md — do not claim physical measurement unless artifacts are labeled.
