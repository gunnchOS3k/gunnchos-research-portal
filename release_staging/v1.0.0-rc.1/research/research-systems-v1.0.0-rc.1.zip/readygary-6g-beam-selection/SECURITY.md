# Security Policy

## Supported versions

| Version | Supported |
|---------|-----------|
| `main` / RC pins | Best effort during Ecosystem RC1 |
| Final product tags | Only when the umbrella release authorizes them |

## Reporting a vulnerability (private only)

**Do not open public GitHub issues for security vulnerabilities.**

1. Prefer GitHub **Private Security Advisories** on this repository.
2. Cross-cutting / unsure routing: open a private advisory on [`gunnchos-research-portal`](https://github.com/gunnchOS3k/gunnchos-research-portal/security/advisories/new) and name this component.
3. Include affected version/SHA and impact. Do **not** attach secrets, PII, or private competition / field datasets.

Public issues that disclose exploitable details may be locked and converted to a private advisory.

## Scope

- No secrets or private datasets in issues/PRs.
- Hardware-related commentary must respect digital-engineering claim boundaries unless a certified hardware program is explicitly in scope.

Do not post exploitable security details publicly. Prefer private advisories: https://github.com/gunnchOS3k/gunnchos-research-portal/security/advisories/new
