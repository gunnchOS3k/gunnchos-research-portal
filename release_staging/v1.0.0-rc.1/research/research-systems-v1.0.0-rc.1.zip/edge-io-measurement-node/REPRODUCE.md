# Reproduce edge-io-measurement-node (RC1)

Accepted main: `af57fbdac857ae386b23b5b747fdc05797621f92`

```bash
git clone https://github.com/gunnchOS3k/edge-io-measurement-node.git
cd edge-io-measurement-node
git checkout af57fbdac857ae386b23b5b747fdc05797621f92
# follow README / Makefile demos on that commit
```

Evidence boundary: see RESEARCH_V1.md — do not claim physical measurement unless artifacts are labeled.
