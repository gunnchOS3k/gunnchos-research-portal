# Reproduce 7gc-digital-twin (RC1)

Accepted main: `dc43a567e3f2e81a5b59fea6dd67c7054cfdde56`

```bash
git clone https://github.com/gunnchOS3k/7gc-digital-twin.git
cd 7gc-digital-twin
git checkout dc43a567e3f2e81a5b59fea6dd67c7054cfdde56
# follow README / Makefile demos on that commit
```

Evidence boundary: see RESEARCH_V1.md — do not claim physical measurement unless artifacts are labeled.
