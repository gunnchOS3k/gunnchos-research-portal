# Reproduce spectrumx-ai-ran-gary (RC1)

Accepted main: `9060655e724374f60cbbb86832816c9c2d332ca4`

```bash
git clone https://github.com/gunnchOS3k/spectrumx-ai-ran-gary.git
cd spectrumx-ai-ran-gary
git checkout 9060655e724374f60cbbb86832816c9c2d332ca4
# follow README / Makefile demos on that commit
```

Evidence boundary: see RESEARCH_V1.md — do not claim physical measurement unless artifacts are labeled.
