# Reproduce ntn-resilience-sim (RC1)

Accepted main: `c4215fc1039f5452917b9b2034b42e03fdc13689`

```bash
git clone https://github.com/gunnchOS3k/ntn-resilience-sim.git
cd ntn-resilience-sim
git checkout c4215fc1039f5452917b9b2034b42e03fdc13689
# follow README / Makefile demos on that commit
```

Evidence boundary: see RESEARCH_V1.md — do not claim physical measurement unless artifacts are labeled.
