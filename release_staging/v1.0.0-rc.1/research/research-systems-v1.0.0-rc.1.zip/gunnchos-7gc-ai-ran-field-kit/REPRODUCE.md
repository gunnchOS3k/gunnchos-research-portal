# Reproduce gunnchos-7gc-ai-ran-field-kit (RC1)

Accepted main: `9e93e41a3b16b009c9cc5163b775360d4d2ef693`

```bash
git clone https://github.com/gunnchOS3k/gunnchos-7gc-ai-ran-field-kit.git
cd gunnchos-7gc-ai-ran-field-kit
git checkout 9e93e41a3b16b009c9cc5163b775360d4d2ef693
# follow README / Makefile demos on that commit
```

Evidence boundary: see RESEARCH_V1.md — do not claim physical measurement unless artifacts are labeled.
