# Security Policy

## Supported versions

| Version | Supported |
|---------|-----------|
| research/main | Best effort |

## Reporting a vulnerability

Do **not** open public issues for sensitive vulnerabilities.

Prefer private advisories via the ecosystem portal:
https://github.com/gunnchOS3k/gunnchos-research-portal/security/advisories/new

Guide: https://github.com/gunnchOS3k/gunnchos-research-portal/blob/main/SECURITY.md

## Scope

- No secrets, tokens, or private competition datasets in issues or PRs.
- Privacy-preserving, opt-in telemetry only for field measurement repos.
